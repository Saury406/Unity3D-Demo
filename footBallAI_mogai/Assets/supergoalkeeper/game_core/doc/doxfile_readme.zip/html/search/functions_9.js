var searchData=
[
  ['reason',['Reason',['../classgame__core_1_1_state.html#af706ddfc49b67c6846b0bde6e1d4ef2b',1,'game_core::State']]]
];
