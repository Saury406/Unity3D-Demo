var searchData=
[
  ['game_5fcore',['game_core',['../namespacegame__core.html',1,'']]]
];
