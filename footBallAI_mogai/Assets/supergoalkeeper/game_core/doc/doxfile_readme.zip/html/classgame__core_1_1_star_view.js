var classgame__core_1_1_star_view =
[
    [ "StarView", "classgame__core_1_1_star_view.html#ae86a197f2bb84a4476c1d081cb2306a4", null ],
    [ "active", "classgame__core_1_1_star_view.html#a8b49a096c496ddf864dc51eefc255424", null ],
    [ "activeStar", "classgame__core_1_1_star_view.html#a9f3f415986dac70a775b5d5055c17b0a", null ],
    [ "gameObject", "classgame__core_1_1_star_view.html#a60689015aa2605309bf677ebcd292ef9", null ],
    [ "position", "classgame__core_1_1_star_view.html#a63ba678903b35bc8967c059467b52563", null ],
    [ "rectTransform", "classgame__core_1_1_star_view.html#acabbab93ac4388b2d8d0073dc03be5f1", null ],
    [ "transform", "classgame__core_1_1_star_view.html#a2a4f6d685ac7603928e5472622b932f3", null ]
];