var classgame__core_1_1particle_sorting_layer =
[
    [ "layerName", "classgame__core_1_1particle_sorting_layer.html#a526f7d6122e456a1798bc8af2f4ed86a", null ],
    [ "order", "classgame__core_1_1particle_sorting_layer.html#a8407d7158679b2f702bb2e1547ba921a", null ]
];