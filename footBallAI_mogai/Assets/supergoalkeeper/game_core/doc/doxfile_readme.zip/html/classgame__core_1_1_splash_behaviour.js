var classgame__core_1_1_splash_behaviour =
[
    [ "levelName", "classgame__core_1_1_splash_behaviour.html#acf46ab0854c77b7850ee21f347f61594", null ],
    [ "timeOut", "classgame__core_1_1_splash_behaviour.html#a50c13cf93fff8d61910d60210183d3b6", null ]
];