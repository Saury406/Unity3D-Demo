var classgame__core_1_1object_fade =
[
    [ "endMarker", "classgame__core_1_1object_fade.html#a4c022362f9d50451c21911aded677355", null ],
    [ "speed", "classgame__core_1_1object_fade.html#a48e10269293199cb8acd3e3b18ef2498", null ],
    [ "startMarker", "classgame__core_1_1object_fade.html#ab9c7ff5c8d29c92834374f89cc73a1a2", null ]
];