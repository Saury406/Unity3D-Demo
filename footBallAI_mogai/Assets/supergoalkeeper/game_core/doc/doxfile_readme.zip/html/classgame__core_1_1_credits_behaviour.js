var classgame__core_1_1_credits_behaviour =
[
    [ "OnClick", "classgame__core_1_1_credits_behaviour.html#a56aefea1dfb2d5a5c724f52152c29b71", null ],
    [ "endMarker", "classgame__core_1_1_credits_behaviour.html#a86c5150ed32fe5cb66cd791af446d8ca", null ],
    [ "speed", "classgame__core_1_1_credits_behaviour.html#a935345fe4a15fcd7e6b39aed6a810f9c", null ]
];