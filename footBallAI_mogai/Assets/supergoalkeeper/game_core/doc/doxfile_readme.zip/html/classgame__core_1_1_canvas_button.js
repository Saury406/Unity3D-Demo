var classgame__core_1_1_canvas_button =
[
    [ "action", "classgame__core_1_1_canvas_button.html#aad6f68c30ef79472d783d95daa7de0a7", null ],
    [ "buttonID", "classgame__core_1_1_canvas_button.html#aae97666d3dcdd12909f21c8d4f7a514c", null ],
    [ "saveId", "classgame__core_1_1_canvas_button.html#ab596bfdec3bb9ace47e12d9637e688a2", null ],
    [ "sceneName", "classgame__core_1_1_canvas_button.html#ab56b72b34f80b8b785b72a96649f3195", null ]
];